This provides a basic Python API for pgenlib; see python_api.txt for details.
Cython and NumPy must be installed.

Build this with e.g.
  python setup.py build_ext
  [sudo] python setup.py install
